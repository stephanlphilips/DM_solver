'''
Created on October 5, 2012

@author: Andrew Cron
'''

import os
include_dir = os.path.dirname(__file__)
#from cyarma import *
